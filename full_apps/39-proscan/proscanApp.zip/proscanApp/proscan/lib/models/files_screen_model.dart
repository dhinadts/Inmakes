class filesList {
  String? image;
  String? titleText;
  String? date;
  String? time;
  String? files;

  filesList(this.image, this.titleText, this.date, this.time, this.files);
}

List<filesList> folderList = [];
