class MIAMealModel{

  String? header;
  String image;
  String text;
  bool added;
  bool pro;

  MIAMealModel({this.header,required this.image,required this.text, required this.added,required this.pro});

}