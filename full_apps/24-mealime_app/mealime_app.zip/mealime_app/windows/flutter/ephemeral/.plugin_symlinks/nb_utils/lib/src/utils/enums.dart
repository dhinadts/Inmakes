enum HttpResponseType { FULL_RESPONSE, JSON, BODY_BYTES, STRING }

enum HttpMethodType { GET, POST, DELETE, PUT }
