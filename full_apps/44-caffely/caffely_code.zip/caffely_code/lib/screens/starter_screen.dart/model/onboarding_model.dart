class OnBoardingModel {
  String? title;
  String? subtitle;
  String? image;

  OnBoardingModel(this.title,this.subtitle,this.image);

}