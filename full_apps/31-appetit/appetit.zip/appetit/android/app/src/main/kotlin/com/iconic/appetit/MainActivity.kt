package com.iconic.appetit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
