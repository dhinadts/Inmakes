import 'package:appetit/utils/ADataProvider.dart';
import 'package:flutter/material.dart';
import 'package:nb_utils/nb_utils.dart';

class APopularRecipesComponent extends StatefulWidget {

  ScrollPhysics? physics;
  APopularRecipesComponent({this.physics});

  @override
  State<APopularRecipesComponent> createState() => _APopularRecipesComponentState();
}

class _APopularRecipesComponentState extends State<APopularRecipesComponent> {
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, childAspectRatio: (1 / 1.5), mainAxisSpacing: 16, crossAxisSpacing: 16),
      physics: widget.physics ?? NeverScrollableScrollPhysics(),
      itemCount: categoryModel.length,
      padding: EdgeInsets.only(left: 16, right: 16, top: 0, bottom: 16),
      shrinkWrap: true,
      itemBuilder: (BuildContext context, int index) {
        return Stack(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.asset(
                categoryModel[index].image.toString(),
                height: MediaQuery
                    .of(context)
                    .size
                    .height * 0.6,
                width: MediaQuery
                    .of(context)
                    .size
                    .width * 0.6,
                fit: BoxFit.cover,
                color: Colors.black.withOpacity(0.37),
                colorBlendMode: BlendMode.darken,
              ),
            ),
            Positioned(
              top: 16,
              right: 16,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.black.withOpacity(0.4),
                ),
                child: IconButton(
                  onPressed: () =>
                      setState(() {
                        categoryModel[index].isBookMark = !categoryModel[index].isBookMark;
                      }),
                  icon: !categoryModel[index].isBookMark
                      ? Icon(Icons.bookmark_border_outlined, color: Colors.white.withOpacity(0.70), size: 30)
                      : Icon(Icons.bookmark, color: Colors.orange.withOpacity(0.70), size: 30),
                  // color: Colors.black.withOpacity(0.4),
                  splashRadius: 25,
                ),
              ),
            ),
            Positioned(
              bottom: 16,
              left: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    width: 100,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.black.withOpacity(0.4), shape: StadiumBorder()),
                      onPressed: () {},
                      child: Row(
                        children: [
                          Icon(Icons.schedule_outlined, color: Colors.white, size: 15),
                          Text(" " + categoryModel[index].views.toString(),
                              style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w300),overflow: TextOverflow.ellipsis,maxLines: 1).expand(),
                        ],
                      ),
                    ),
                  ),
                  Text(
                    categoryModel[index].data.toString(),
                    style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}
