/* font sizes*/
const applicationName = "Job Search";

const iconSize = 22.0;
const textFieldHeight = 50.0;
const isDarkModeOnPref = 'isDarkModeOnPref';
