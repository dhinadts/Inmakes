const RFWidgetHeight = 300;
const bottomNavigationIconSize = 16.0;
const textSizeLargeMedium = 18.0;
const textSizeMedium = 16.0;
const isDarkModeOnPref = 'isDarkModeOnPref';
const fontSemibold = 'Semibold';
