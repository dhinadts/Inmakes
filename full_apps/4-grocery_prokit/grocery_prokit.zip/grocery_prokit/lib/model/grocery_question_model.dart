class Question {
  var question;
  var answer;

  Question({this.question, this.answer});
}

List<Question> question = [
  Question(
    question: 'Do you charge any extra devilery costs? if yes how huch?',
    answer: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.",
  ),
  Question(
    question: 'To complete my order I have to use my credit card, how secure is my information?',
    answer:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
  ),
];
