class AllStores {
  var storeName;
  var storeAddress;

  AllStores({this.storeName, this.storeAddress});
}

List<AllStores> allStores = [
  AllStores(
    storeName: 'Aluthgama',
    storeAddress: 'Do childhood earaches cause hearing loss later in life?',
  ),
  AllStores(
    storeName: 'Arangala',
    storeAddress: 'What alternative therapies can ber used to trewwat migranie?',
  ),
  AllStores(
    storeName: 'Aththidiya',
    storeAddress: 'What is chronic sinusitis?',
  )
];
