
import 'package:grocery_prokit/utils/GroceryConstant.dart';

const Grocery_ic_DeliveryBoy = "$BaseUrl/images/grocery/Grocery_ic_DeliveryBoy.png";
const Grocery_ic_CheckMark = "images/grocery/Grocery_ic_CheckMark.png";
const Grocery_ic_Profile = "$BaseUrl/images/grocery/Grocery_ic_Profile.jpg";
const Grocery_ic_Dollar = "images/grocery/Grocery_ic_Dollar.png";
const Grocery_ic_Lock = "images/grocery/Grocery_ic_Lock.png";
const Grocery_ic_DeliveryTruck = "images/grocery/Grocery_ic_DeliveryTruck.png";
const Grocery_ic_User = "images/grocery/Grocery_ic_User.png";
const Grocery_ic_Logout = "images/grocery/Grocery_ic_Logout.png";
const Grocery_ic_Home = "images/grocery/Grocery_ic_Home.png";
const Grocery_ic_bag = "images/grocery/Grocery_ic_bag.png";
const Grocery_ic_Android = "images/grocery/Grocery_ic_Android.jpg";

const grocery_ic_visa = "images/grocery/visa.png";
const grocery_ic_masterCard = "$BaseUrl/images/grocery/masterCard.png";

const grocery_ic_shop = "images/grocery/grocery_ic_shop.png";
const grocery_ic_outline_favourite = "images/grocery/grocery_ic_outline_favourite.png";
const grocery_ic_grocery = "images/grocery/grocery_ic_grocery.png";
const grocery_ic_liquor = "images/grocery/grocery_ic_liquor.png";
const grocery_ic_chilled = "images/grocery/grocery_ic_chilled.png";
const grocery_ic_pharmacy = "images/grocery/grocery_ic_pharmacy.png";
const grocery_ic_frozen = "images/grocery/grocery_ic_frozen.png";
const grocery_ic_vegetables = "images/grocery/grocery_ic_vegetables.png";
const grocery_ic_meat = "images/grocery/grocery_ic_meat.png";
const grocery_ic_fish = "images/grocery/grocery_ic_fish.png";
const grocery_ic_homeware = "images/grocery/grocery_ic_homeware.png";
const grocery_ic_fruit = "images/grocery/grocery_ic_fruit.png";
const grocery_ic_user1 = "$BaseUrl/images/grocery/grocery_ic_user1.png";
const grocery_ic_user2 = "$BaseUrl/images/grocery/grocery_ic_user2.png";
const grocery_ic_user3 = "$BaseUrl/images/grocery/grocery_ic_user3.png";
const grocery_ic_bell_paper = "$BaseUrl/images/grocery/grocery_ic_bell_paper.png";
const grocery_ic_ginger = "$BaseUrl/images/grocery/grocery_ic_ginger.png";
const grocery_ic_graps = "$BaseUrl/images/grocery/grocery_ic_graps.png";
const grocery_ic_apple = "$BaseUrl/images/grocery/grocery_ic_apple.png";
const grocery_ic_bg_drinks = "$BaseUrl/images/grocery/grocery_ic_bg_drinks.jpg";
const grocery_ic_carts = "$BaseUrl/images/grocery/grocery_ic_carts.png";
const grocery_logo = "$BaseUrl/images/grocery/grocery_logo.png";
const grocery_ic_logo = "images/grocery/grocery_ic_logo.png";
const grocery_ic_carrot = "$BaseUrl/images/grocery/grocery_ic_carrot.png";
