class ShPaymentCard {
  var cardNo = "3434 3434 3434";
  var month = "01";
  var year = "2021";
  var cvv = "123";
  var holderName = "John";
}
