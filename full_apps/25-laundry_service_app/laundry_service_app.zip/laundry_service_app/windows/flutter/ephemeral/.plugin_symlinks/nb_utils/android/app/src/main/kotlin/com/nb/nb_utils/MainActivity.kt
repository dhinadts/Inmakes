package com.nb.nb_utils

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
