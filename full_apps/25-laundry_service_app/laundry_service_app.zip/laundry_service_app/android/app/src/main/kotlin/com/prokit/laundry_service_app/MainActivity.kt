package com.prokit.laundry_service_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
