class LSSelectionModel {
  String? title;
  int? index;
  String? subTitle;

  LSSelectionModel({this.title, this.index, this.subTitle});
}