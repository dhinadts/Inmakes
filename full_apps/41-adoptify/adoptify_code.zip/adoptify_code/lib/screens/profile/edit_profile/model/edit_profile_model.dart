class GenderModel {
  final String gender;

  GenderModel({required this.gender});
}
