class Assets {
  static const String iconsIcNoPhoto = 'assets/icons/ic_no_photo.png';
}