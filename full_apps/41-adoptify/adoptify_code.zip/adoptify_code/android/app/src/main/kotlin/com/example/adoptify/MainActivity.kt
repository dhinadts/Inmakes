package com.example.adoptify

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
