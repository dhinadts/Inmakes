class Constants {
  static const perPageItem = 20;
  static var labelTextSize = 15;
  static const appLogoSize = 98.0;
  static const DECIMAL_POINT = 2;
  static const loaderScreen = 38.0;
}
