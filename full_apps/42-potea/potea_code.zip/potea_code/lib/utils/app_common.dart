import 'package:flutter/material.dart';
import 'package:get/get.dart';

extension BuildContextExt on BuildContext {
  bool get isDarkMode => Theme.of(this).brightness == Brightness.dark;
}

RxBool isDarkMode = false.obs;