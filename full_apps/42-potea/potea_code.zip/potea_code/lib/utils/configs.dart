const APP_NAME = 'Potea';
const BaseUrl = 'https://assets.iqonic.design/old-themeforest-images/prokit';
