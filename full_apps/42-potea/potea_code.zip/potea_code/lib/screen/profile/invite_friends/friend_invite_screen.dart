import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:potea/components/app_scaffold.dart';
import 'package:potea/screen/profile/invite_friends/friend_invite_controller.dart';
import 'package:potea/screen/profile/invite_friends/friend_tile.dart';

class InviteFriendsScreen extends StatelessWidget {
  final FriendsController controller = Get.put(FriendsController());

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      appBarTitle: Text('Invite Friends', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      body: Obx(
        () => ListView.builder(
          itemCount: controller.friends.length,
          itemBuilder: (context, index) {
            return FriendTile(
              friend: controller.friends[index],
              onInviteToggle: () => controller.toggleInvite(index),
            );
          },
        ),
      ),
    );
  }
}
