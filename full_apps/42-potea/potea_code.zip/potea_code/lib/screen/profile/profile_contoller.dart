import 'package:get/get.dart';

import '../../utils/app_common.dart';

class ProfileController extends GetxController {
  void toggleDarkMode(bool newValue) {
    isDarkMode.value = newValue;
  }
}
