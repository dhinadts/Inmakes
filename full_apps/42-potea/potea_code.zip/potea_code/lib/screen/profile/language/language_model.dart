class LanguageModel {
  final String lang;

  LanguageModel({
    required this.lang,
  });
}
