class PrivacyModel {
  final String text;
  final String description;

  PrivacyModel(this.text, this.description);
}
