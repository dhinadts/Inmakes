class FAQSelectedModel {
  int id;
  String name;

  FAQSelectedModel({
    this.id = -1,
    this.name = '',
  });
}
