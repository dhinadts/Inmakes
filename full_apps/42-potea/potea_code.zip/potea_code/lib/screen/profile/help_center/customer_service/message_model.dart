class Message {
  final String text;
  final bool isSent;
  final String time;

  Message({required this.text, required this.isSent, required this.time});
}