class AmountModal {
  final int amount;

  AmountModal(this.amount);
}
