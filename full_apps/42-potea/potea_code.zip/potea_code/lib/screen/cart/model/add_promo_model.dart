class AddPromoModel {
  int id;
  String heading;
  String subtitle;

  AddPromoModel({
    this.id = -1,
    this.heading = '',
    this.subtitle = '',
  });
}
