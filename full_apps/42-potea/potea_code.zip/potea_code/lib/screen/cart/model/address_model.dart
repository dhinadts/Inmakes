class AddressModel {
  int id;
  String place;
  String address;

  AddressModel({
    this.id = -1,
    this.place = '',
    this.address = '',
  });
}
