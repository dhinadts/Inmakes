import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:potea/components/app_scaffold.dart';
import 'package:potea/screen/cart/enter_pin/enter_pin_controller.dart';
import 'package:potea/screen/dashboard/dashboard.dart';
import 'package:potea/screen/order/e_receipt_screen.dart';
import 'package:potea/screen/order/transaction_screen.dart';
import 'package:potea/utils/app_common.dart';
import 'package:potea/utils/colors.dart';
import 'package:potea/utils/image.dart';

class EnterPin extends StatelessWidget {
  final EnterPinController pinController = Get.put(EnterPinController());
  final List<FocusNode> _focusNodes = List.generate(4, (_) => FocusNode());

  @override
  Widget build(BuildContext context) {
    for (int i = 0; i < _focusNodes.length - 1; i++) {
      _focusNodes[i].addListener(() {
        if (!_focusNodes[i].hasFocus) {
          _focusNodes[i + 1].requestFocus();
        }
      });
    }
    return AppScaffold(
      appBarTitle: Text('Enter Your PIN', style: TextStyle(fontSize: 18)),
      body: Stack(
        children: [
          Form(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  'Enter your PIN to confirm payment',
                  style: TextStyle(fontSize: 16),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: Get.height * 0.070),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: List.generate(
                    _focusNodes.length,
                    (index) => Obx(() => _buildPinField(context, pinController.hidePin.value, _focusNodes[index])),
                  ),
                ),
                SizedBox(height: Get.height * 0.070),
              ],
            ).paddingSymmetric(horizontal: 16),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: AppButton(
              width: Get.width,
              height: Get.height * 0.02,
              color: primaryColor,
              shapeBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(50)),
              onTap: () async {
                showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (BuildContext context) {
                    return Obx(
                      () => AlertDialog(
                        shape: OutlineInputBorder(borderRadius: BorderRadius.circular(50)),
                        content: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Image.network(imageCong, width: 100, height: 100),
                            Text(
                              'Order Successful!',
                              style: TextStyle(fontSize: 20, color: isDarkMode.value ? white : black, fontWeight: FontWeight.bold),
                            ),
                            SizedBox(height: Get.height * 0.02),
                            Text(
                              'You have successfully made order',
                              textAlign: TextAlign.center,
                              style: TextStyle(fontSize: 16),
                            ),
                            SizedBox(height: Get.height * 0.02),
                            AppButton(
                              elevation: 0,
                              width: Get.width,
                              height: Get.height * 0.02,
                              onTap: () {
                                Get.offAll(() => DashboardScreen());
                                Get.to(() => TransactionScreen());
                              },
                              color: primaryColor,
                              shapeBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(50)),
                              child: Text(
                                'View Order',
                                style: TextStyle(fontSize: 16, color: white),
                              ),
                            ).paddingSymmetric(horizontal: 16),
                            SizedBox(height: Get.height * 0.02),
                            AppButton(
                              elevation: 0,
                              width: Get.width,
                              height: Get.height * 0.02,
                              onTap: () {
                                Get.to(() => EReceiptScreen());
                              },
                              color: primaryColor,
                              shapeBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(50)),
                              child: Text(
                                'View E-Receipt',
                                style: TextStyle(fontSize: 16, color: white),
                              ),
                            ).paddingSymmetric(horizontal: 16),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
              child: Text(
                'Continue',
                style: TextStyle(fontSize: 16, color: white),
              ),
            ).paddingAll(16),
          ),
        ],
      ),
    );
  }

  Widget _buildPinField(BuildContext context, bool hidePin, FocusNode focusNode) {
    return Container(
      height: 60,
      width: 70,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        border: Border.all(
          color: focusNode.hasFocus ? primaryColor : commonDividerColor,
        ),
        borderRadius: BorderRadius.circular(16),
        color: focusNode.hasFocus ? (isDarkMode.value ? darkFocusedColor : lightFocusedColor) : context.cardColor,
      ),
      child: TextFormField(
        focusNode: focusNode,
        obscureText: hidePin,
        onChanged: (value) {
          if (value.length == 1) {
            FocusScope.of(context).unfocus();
          }
        },
        style: TextStyle(fontSize: 25, color: isDarkMode.value ? white : black),
        keyboardType: TextInputType.number,
        textAlign: TextAlign.center,
        inputFormatters: [
          LengthLimitingTextInputFormatter(1),
          FilteringTextInputFormatter.digitsOnly,
        ],
        decoration: InputDecoration(
          border: InputBorder.none,
        ),
      ),
    );
  }
}
