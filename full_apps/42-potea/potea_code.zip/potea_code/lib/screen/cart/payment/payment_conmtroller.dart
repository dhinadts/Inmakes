import 'package:get/get.dart';
import 'package:potea/screen/cart/model/payment_model.dart';
import 'package:potea/utils/image.dart';

class PaymentController extends GetxController {
  var payment = <PaymentModel>[
    PaymentModel(profileImage: icPaypal, paymentType: 'PayPal', price: '\$9.449'),
    PaymentModel(profileImage: icGoogle, paymentType: 'Google Pay', price: '\$9.449'),
    PaymentModel(profileImage: icAppleWhite, paymentType: 'Apple Pay', price: '\$9.449'),
    PaymentModel(profileImage: walletMastercard, paymentType: 'Credit/Debit card', price: '\$9.449'),
  ].obs;

  var selectedpayment = Rx<PaymentModel?>(null);

  void setSelectedpayment(PaymentModel? payments) {
    selectedpayment.value = payments;
  }
}
