import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:potea/screen/auth/create_new_pass/create_new_pass.dart';
import 'package:potea/screen/auth/forgot_pass/forgot_pin_controller.dart';
import 'package:potea/utils/app_common.dart';
import 'package:potea/utils/colors.dart';

class ForgotPassPin extends StatelessWidget {
  final ForgotPinController forgotpinController = Get.put(ForgotPinController());
  final List<FocusNode> _focusNodes = List.generate(4, (_) => FocusNode());

  @override
  Widget build(BuildContext context) {
    for (int i = 0; i < _focusNodes.length - 1; i++) {
      _focusNodes[i].addListener(() {
        if (!_focusNodes[i].hasFocus) {
          _focusNodes[i + 1].requestFocus();
        }
      });
    }
    return Stack(
      children: [
        Scaffold(
          appBar: AppBar(
            title: Text('Create New PIN'),
          ),
          body: Form(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Code has been send to +1 111 ******99', style: TextStyle(fontSize: 16)),
                SizedBox(height: Get.height * 0.070),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: List.generate(
                    _focusNodes.length,
                    (index) => Obx(() => _buildPinField(context, _focusNodes[index])),
                  ),
                ),
                SizedBox(height: Get.height * 0.070),
                Obx(
                  () => forgotpinController.timeLeft.value > 0
                      ? RichText(
                          text: TextSpan(
                            text: 'Resend code in ',
                            style: TextStyle(color: isDarkMode.value ? white : black),
                            children: <TextSpan>[
                              TextSpan(text: '${forgotpinController.timeLeft.value}', style: TextStyle(color: primaryColor)),
                              TextSpan(text: ' s'),
                            ],
                          ),
                        )
                      : AppButton(
                          elevation: 0,
                          width: Get.width * 0.02,
                          height: Get.height * 0.02,
                          color: primaryColor,
                          shapeBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(50)),
                          onTap: () {
                            forgotpinController.resetTimer();
                          },
                          child: Text('Resend', style: TextStyle(fontSize: 16, color: white)),
                        ),
                ),
              ],
            ),
          ),
        ),
        Positioned(
          bottom: 16,
          left: 16,
          right: 16,
          child: AppButton(
            width: Get.width,
            height: Get.height * 0.02,
            color: primaryColor,
            shapeBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(50)),
            onTap: () {
              Get.to(() => CreateNewPass());
            },
            child: Text('Verify', style: TextStyle(fontSize: 16, color: white)),
          ).paddingSymmetric(horizontal: 16),
        ),
      ],
    );
  }

  Widget _buildPinField(BuildContext context, FocusNode focusNode) {
    return Container(
      height: 60,
      width: 70,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        border: Border.all(color: focusNode.hasFocus ? primaryColor : commonDividerColor),
        borderRadius: BorderRadius.circular(16),
        color: focusNode.hasFocus ? (isDarkMode.value ? darkFocusedColor : lightFocusedColor) : context.cardColor,
      ),
      child: TextFormField(
        focusNode: focusNode,
        onChanged: (value) {
          if (value.length == 1) {
            FocusScope.of(context).unfocus();
          }
        },
        style: TextStyle(fontSize: 25, color: isDarkMode.value ? white : black),
        keyboardType: TextInputType.number,
        textAlign: TextAlign.center,
        inputFormatters: [
          LengthLimitingTextInputFormatter(1),
          FilteringTextInputFormatter.digitsOnly,
        ],
        decoration: InputDecoration(border: InputBorder.none),
      ),
    );
  }
}
