import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:potea/components/app_scaffold.dart';
import 'package:potea/screen/splash/splashScreenController.dart';
import 'package:potea/utils/constants.dart';
import 'package:potea/utils/image.dart';

class SplashScreen extends StatelessWidget {
  SplashScreen({Key? key}) : super(key: key);
  final SplashController controller = Get.put(SplashController());

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      hideAppBar: true,
      body: Stack(
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Center(
                child: SvgPicture.network(
                  assetsPotea,
                  height: Constants.appLogoSize,
                  width: Constants.appLogoSize,
                  fit: BoxFit.contain,
                ),
              ),
            ],
          ),
          Positioned(
            bottom: 26,
            left: 16,
            right: 16,
            child: Lottie.network(lottiePoteaLoader, width: 0, height: 130),
          ),
        ],
      ),
    );
  }
}
