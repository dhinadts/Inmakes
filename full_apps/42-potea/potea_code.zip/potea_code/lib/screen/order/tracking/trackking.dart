import 'package:dashed_stepper/dashed_stepper.dart';
import 'package:flutter/material.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:potea/utils/colors.dart';
import 'package:potea/utils/image.dart';

class Tracking extends StatelessWidget {
  const Tracking({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        DashedStepper(
          indicatorColor: primaryColor,
          disabledColor: lightGrey,
          height: 30,
          gap: 1,
          icons: const [
            Image(image: NetworkImage(icLogistics), color: primaryColor, height: 25),
            Image(image: NetworkImage(icDeliveryTruck), color: primaryColor, height: 25),
            Image(image: NetworkImage(icDelivery), height: 25),
            Image(image: NetworkImage(icOrder), height: 25),
          ],
          length: 4,
          step: 2,
        ),
      ],
    );
  }
}
