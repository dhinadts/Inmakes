import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:potea/components/app_scaffold.dart';
import 'package:potea/components/searchbar_widget.dart';
import 'package:potea/screen/order/e_receipt_screen.dart';
import 'package:potea/screen/order/order_main_controller.dart';
import 'package:potea/utils/app_common.dart';
import 'package:potea/utils/colors.dart';
import 'package:potea/utils/image.dart';

class TransactionScreen extends StatelessWidget {
  TransactionScreen({super.key});

  final OrderMainController orderMainController = Get.put(OrderMainController());

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      appBarTitle: Text('Transaction History', style: TextStyle(fontSize: 18)),
      actions: [
        InkWell(
          onTap: () {
            Get.to(() => SearchBarWidget());
          },
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Image.network(
              icSearch,
              height: Get.height * 0.24,
              color: isDarkMode.value ? white : black,
            ),
          ),
        ),
      ],
      body: Obx(
        () => ListView.builder(
          itemCount: orderMainController.orderList.length,
          itemBuilder: (context, index) {
            final order = orderMainController.orderList[index];
            return ListTile(
              leading: CircleAvatar(
                radius: 25,
                backgroundColor: Colors.transparent,
                child: ClipOval(
                  child: Image.network(
                    order.image,
                    fit: BoxFit.cover,
                    width: Get.width * 0.45,
                    height: Get.height * 0.45,
                  ),
                ),
              ),
              title: Row(
                children: [
                  Text(order.itemName, style: TextStyle(fontSize: 14)),
                  Spacer(),
                  Text('\$' + order.total, style: TextStyle(color: primaryColor, fontSize: 14)),
                ],
              ),
              subtitle: Row(
                children: [
                  Text(order.date, style: TextStyle(fontSize: 12)),
                  Spacer(),
                  Text(order.category, style: TextStyle(fontSize: 14)),
                ],
              ),
              onTap: () {
                orderMainController.selectOrder(order);
                Get.to(() => EReceiptScreen());
              },
            );
          },
        ),
      ),
    );
  }
}
