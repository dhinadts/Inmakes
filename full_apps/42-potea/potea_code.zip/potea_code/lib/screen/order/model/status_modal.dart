class TextDto {
  final String message;
  final String? date;

  TextDto(this.message, this.date);
}
