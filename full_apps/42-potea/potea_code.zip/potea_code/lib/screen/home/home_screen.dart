import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:potea/components/app_scaffold.dart';
import 'package:potea/components/searchbar_widget.dart';
import 'package:potea/screen/dashboard/dashboard_controller.dart';
import 'package:potea/screen/home/filter/filter_screen.dart';
import 'package:potea/screen/home/most_popular_component/most_popular_home_component.dart';
import 'package:potea/screen/home/notification/notification_screen.dart';
import 'package:potea/screen/home/special_offer_component/Special_offer_home_component.dart';
import 'package:potea/screen/home/whishlist/whishlist_controller.dart';
import 'package:potea/screen/home/whishlist/whishlist_screen.dart';
import 'package:potea/utils/colors.dart';
import 'package:potea/utils/common_base.dart';
import 'package:potea/utils/image.dart';

class HomeScreen extends StatelessWidget {
  final WishlistController wishlistController = Get.put(WishlistController());

  HomeScreen({super.key});

  // final FilterController filterController = Get.put(FilterController());
  final HomeController homeController = Get.put(HomeController());

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        return homeController.onWillPop(context);
      },
      child: AppScaffold(
        hasLeadingWidget: false,
        actions: [
          IconButton(
            onPressed: () {
              hideKeyboard(context);
              Get.to(
                NotificationScreen(),
              );
            },
            icon: icNotification.iconImage(fit: BoxFit.contain, size: 23),
          ),
          IconButton(
            onPressed: () {
              hideKeyboard(context);
              Get.to(() => WishlistScreen());
            },
            icon: icHeart.iconImage(fit: BoxFit.contain, size: 23),
          ),
          8.width,
        ],
        appBarTitle: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 25,
                backgroundImage: NetworkImage(userIm),
              ),
              SizedBox(width: Get.width * 0.03),
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Good Morning 👋', style: TextStyle(color: Colors.grey, fontSize: 14)),
                  Text('Andrew Ainsley', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ],
              ),
            ],
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: TextFormField(
                  readOnly: true,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Theme.of(context).cardColor,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none),
                    hintText: 'Search Here',
                    hintStyle: TextStyle(color: Colors.grey.shade500),
                    prefixIcon: Icon(Icons.search_rounded, color: Colors.grey.shade500),
                    suffixIcon: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: IconButton(
                        icon: Image.network(icFlt, width: 24, color: primaryColor),
                        onPressed: () {
                          showModalBottomSheet(
                            context: context,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(30),
                                topRight: Radius.circular(30),
                              ),
                            ),
                            isScrollControlled: true,
                            builder: (BuildContext context) {
                              return filter_bottom();
                            },
                          );
                        },
                      ),
                    ),
                  ),
                  onTap: () {
                    hideKeyboard(context);
                    Get.to(() => SearchBarWidget());
                  },
                ),
              ),
              SizedBox(height: 20),
              SpecialOffer(),
              SizedBox(height: 20),
              MostPopularOffer(),
              30.height,
            ],
          ),
        ),
      ),
    );
  }
}
