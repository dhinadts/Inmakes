import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:potea/screen/auth/option_screen.dart';
import 'package:potea/screen/home/model/plant_image_model.dart';
import 'package:potea/utils/image.dart';

class DetailProductController extends GetxController {
  PageController pageController = PageController();

  RxInt currentPage = 0.obs;

  List<PlantImageModel> plantDetails = [
    PlantImageModel(image: imagePlbest),
    PlantImageModel(image: imagePlbestTWO),
    PlantImageModel(image: imagePlbestTHREE),
  ];

  void handleNext() {
    pageController.nextPage(duration: const Duration(milliseconds: 100), curve: Curves.bounceIn);
    if (currentPage.value == (plantDetails.length - 1)) {
      Get.to(() => OptionScreen());
    }
  }

  @override
  void onClose() {
    if (Get.context != null) {
      setStatusBarColor(Get.context!.primaryColor, statusBarIconBrightness: Brightness.light, statusBarBrightness: Brightness.light);
    }
    super.onClose();
  }
}
