import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:potea/components/app_scaffold.dart';
import 'package:potea/screen/home/review/review_controller.dart';
import 'package:potea/screen/home/review/review_tile.dart';
import 'package:potea/utils/app_common.dart';
import 'package:potea/utils/colors.dart';
import 'package:potea/utils/image.dart';

class ReviewsScreen extends StatelessWidget {
  final ReviewsController reviewsController = Get.put(ReviewsController());

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      appBarTitle: Text('4.6 (5,389 reviews)', style: TextStyle(fontSize: 18)),
      actions: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Image.network(
            icSearch,
            height: 24,
            color: isDarkMode.value ? white : black,
          ),
        ),
      ],
      body: Column(
        children: [
          16.height,
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Obx(
              () => Row(
                children: reviewsController.ratings.map((rating) {
                  final isSelected = reviewsController.selectedRating.value == rating;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8.0),
                    child: ChoiceChip(
                      showCheckmark: false,
                      label: Row(
                        children: [
                          Image.network(
                            isSelected ? icRatWhite : icRat,
                            height: 14,
                          ),
                          8.width,
                          Text(rating, style: TextStyle(color: isSelected ? white : primaryColor)),
                        ],
                      ),
                      selected: isSelected,
                      onSelected: (isSelected) {
                        reviewsController.selectedRating.value = rating;
                      },
                      selectedColor: primaryColor,
                      backgroundColor: context.cardColor,
                      shape: RoundedRectangleBorder(
                        side: BorderSide(color: primaryColor, width: 1.5),
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
          Expanded(
            child: Obx(() {
              return ListView.builder(
                padding: EdgeInsets.all(8.0),
                itemCount: reviewsController.reviews.length,
                itemBuilder: (context, index) {
                  final review = reviewsController.reviews[index];
                  return ReviewTile(
                    reviewData: review,
                  );
                },
              );
            }),
          ),
        ],
      ),
    );
  }
}
