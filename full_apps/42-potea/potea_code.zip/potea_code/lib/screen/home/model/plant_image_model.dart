
class PlantImageModel {
  String? image;

  PlantImageModel({
    this.image,
  });
}
