class PlantModel {
  int id;
  String name;
  String PlantImage;

  PlantModel({
    this.id = -1,
    this.name = '',
    this.PlantImage = '',
  });
}
