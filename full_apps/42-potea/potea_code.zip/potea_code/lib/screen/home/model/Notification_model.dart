class Order {
  int id;
  String text;
  String subText;
  String profileImage;
  String day;

  Order({
    this.id = -1,
    this.text = '',
    this.subText = '',
    this.profileImage = '',
    this.day = 'Unknown',
  });
}
