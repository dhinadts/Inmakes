import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:potea/screen/auth/option_screen.dart';
import 'package:potea/screen/walkthrough/model/walkthrough_model.dart';
import 'package:potea/utils/image.dart';

class WalkthroughController extends GetxController {
  PageController pageController = PageController();

  RxInt currentPage = 0.obs;

  List<WalkThroughElementModel> walkthroughDetails = [
    WalkThroughElementModel(image1: walkthroughWalkthroughLightOne, image2: walkthroughWalkthroughDarkOne, title: 'We provide high quality plants just for you'),
    WalkThroughElementModel(image1: walkthroughWalkthroughLightTwoRemovebg, image2: walkthroughWalkthroughLightTwoRemovebg, title: 'Your satisfaction is our number one priority'),
    WalkThroughElementModel(image1: walkthroughWalkthroughLightThreeRemovebg, image2: walkthroughWalkthroughLightThreeRemovebg, title: "Let's Shop Your Favorite Plants with Potea Now!"),
  ];

  void handleNext() {
    if (currentPage.value < walkthroughDetails.length - 1) {
      pageController.nextPage(
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    } else {
      Get.to(() => OptionScreen());
    }
  }

  @override
  void onClose() {
    if (Get.context != null) {
      setStatusBarColor(Get.context!.primaryColor, statusBarIconBrightness: Brightness.light, statusBarBrightness: Brightness.light);
    }
    super.onClose();
  }
}
