
class WalkThroughElementModel {
  String? title;
  String? image1;
  String? image2;

  WalkThroughElementModel({
    this.title,
    this.image1,
    this.image2,
  });
}
