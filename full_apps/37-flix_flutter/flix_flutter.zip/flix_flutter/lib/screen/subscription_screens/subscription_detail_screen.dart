import 'package:flutter/material.dart';
import 'package:prokit_flutter/screen/subscription_screens/subscription_plan_screen.dart';

class SubscriptionDetailsScreen extends StatefulWidget {
  State<SubscriptionDetailsScreen> createState() => SubscriptionDetailsScreenState();
}

class SubscriptionDetailsScreenState extends State<SubscriptionDetailsScreen> {
  @override
  Widget build(BuildContext context) {
    return SubScriptionPlanScreen();
  }
}
