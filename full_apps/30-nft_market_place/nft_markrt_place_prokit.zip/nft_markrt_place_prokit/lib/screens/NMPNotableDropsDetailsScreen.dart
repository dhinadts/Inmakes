import 'package:flutter/material.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:opensea_ui/utils/OSConstants.dart';
import 'package:opensea_ui/utils/OSDataProvider.dart';
import 'package:opensea_ui/components/NMPNotableTrendingComponent.dart';

import '../utils/OSCommon.dart';

class NMPNotableDropsDetailsScreen extends StatefulWidget {
  final OSDataModel dataModel;

  NMPNotableDropsDetailsScreen(this.dataModel);

  @override
  NMPNotableDropsDetailsScreenState createState() => NMPNotableDropsDetailsScreenState();
}

class NMPNotableDropsDetailsScreenState extends State<NMPNotableDropsDetailsScreen> {
  List<OSDataModel> notableDropsDetails = getTapNotableDropsDetails();

  @override
  void initState() {
    super.initState();
    init();
  }

  Future<void> init() async {
    setStatusBarColor(Colors.transparent);
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                commonCachedNetworkImage(
                  widget.dataModel.image!,
                  height: 300,
                  width: MediaQuery.of(context).size.width,
                  fit: BoxFit.cover,
                ),
                Positioned(
                  top: 50,
                  left: 15,
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                    child: InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        height: 50,
                        width: 50,
                        color: Theme.of(context).cardColor,
                        alignment: Alignment.center,
                        child: Icon(Icons.arrow_back_ios, color: Theme.of(context).iconTheme.color),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 20,
                  left: 15,
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(75)),
                    child: InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        height: 150,
                        width: 150,
                        color: Theme.of(context).cardColor,
                        alignment: Alignment.center,
                        child: commonCachedNetworkImage(
                          '$osImageBaseUrl/os_dog.jpg',
                          height: 150,
                          width: MediaQuery.of(context).size.width,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(widget.dataModel.title!, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Text(
                        "ProKit – Biggest Flutter UI kit is the ultimate library of Flutter UI templates "
                        "combined into a high-quality Flutter UI kit for Android/iOS developers. "
                        "The collection consists of UI elements and styles based on Material Design Guidelines. "
                        "With its clean and direct effect, this set of mixed App UI design easily becomes your standalone solution.",
                        textAlign: TextAlign.justify,
                        style: TextStyle(fontSize: 12)),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        children: [
                          Text('9', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                          Text('Items', style: TextStyle(color: Colors.grey, fontSize: 12)),
                        ],
                      ),
                      Column(
                        children: [
                          Text('1', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                          Text('Owners', style: TextStyle(color: Colors.grey, fontSize: 12)),
                        ],
                      ),
                      Row(
                        children: [
                          commonCachedNetworkImage('$osImageBaseUrl/icons/os_ic_token.png', width: 20, height: 20, alignment: Alignment.topCenter, color: Theme.of(context).iconTheme.color),
                          Column(
                            children: [
                              Text('0.179', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                              Text('Price', style: TextStyle(color: Colors.grey, fontSize: 12)),
                            ],
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          commonCachedNetworkImage('$osImageBaseUrl/icons/os_ic_token.png', width: 20, height: 20, alignment: Alignment.topCenter, color: Theme.of(context).iconTheme.color),
                          Column(
                            children: [
                              Text('143', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                              Text('Traded', style: TextStyle(color: Colors.grey, fontSize: 12)),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: TextField(
                    decoration: InputDecoration(
                        prefixIcon: Icon(Icons.search),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        hintStyle: TextStyle(color: Colors.grey),
                        hintText: "Search items",
                        fillColor: Colors.white),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Wrap(
                    children: notableDropsDetails.map((data) {
                      return NMPNotableTrendingComponent(data);
                    }).toList(),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
