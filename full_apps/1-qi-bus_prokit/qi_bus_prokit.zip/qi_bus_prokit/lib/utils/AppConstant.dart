

const fontMedium = 'Medium';
const fontSemibold = 'Semibold';

/* font sizes*/
const textSizeSMedium = 14.0;
const textSizeMedium = 16.0;
const textSizeLargeMedium = 18.0;

const BaseUrl = 'https://assets.iqonic.design/old-themeforest-images/prokit';


