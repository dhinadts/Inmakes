/// Icons
const ic_thunder = 'assets/icons/thunderbolt.png';
const ic_facebook = 'assets/icons/facebook.png';
const ic_google = 'assets/icons/google.png';
const ic_filter = 'assets/icons/filter.png';
const ic_terms_condition = 'assets/icons/term_condition.png';
const ic_foods = 'assets/icons/foods.png';
const ic_pharmacy = 'assets/icons/pharmacy.png';
const ic_shopping = 'assets/icons/shopping.png';
const ic_washroom = 'assets/icons/washroom.png';
const ic_wifi = 'assets/icons/wifi.png';
const ic_navigation = 'assets/icons/navigation.png';
const ic_marker2 = 'assets/icons/ic_marker.png';

/// Images
const splash_image = "assets/images/splash_image.jpg";
const splash_image2 = "assets/images/splash_image2.jpeg";
const ev_station1 = "assets/images/ev_station1.jpg";
const ev_station2 = "assets/images/ev_station2.jpg";
const ev_station3 = "assets/images/ev_station3.jpg";
const person_image = "assets/images/person_image.jpeg";
const add_check_in_image = "assets/images/add_check_in_image.jpg";
const conn_type_img_first = "assets/images/connection_Image_first.png";
const conn_type_img_second = "assets/images/connection_img_second.png";
