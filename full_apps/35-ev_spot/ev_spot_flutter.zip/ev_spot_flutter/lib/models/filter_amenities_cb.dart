class AmenitiesCB {
  String? amenitiesCBTitle;
  bool isAmenitiesChecked = false;

  AmenitiesCB({required this.amenitiesCBTitle});
}
