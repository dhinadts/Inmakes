package com.example.banking_prokit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
