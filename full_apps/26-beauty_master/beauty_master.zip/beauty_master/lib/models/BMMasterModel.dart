class BMMasterModel{

  String image;
  String name;

  BMMasterModel({required this.image,required this.name});

}