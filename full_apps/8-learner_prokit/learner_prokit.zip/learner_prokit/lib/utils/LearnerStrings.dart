const learner_sample_long_text = "Lorem Ipsum is simply dummy text of the printing and typesetting industry.";
const learner_Get_Started = "Get Started";
const learner_hint_email = "Email";
const learner_hint_password = "Password";
const learner_lbl_enter = "Enter";
const learner_sign_up_info = "By Pressing 'Join' you agree to our";

const learner_hint_full_name = "Full Name";
const learner_lbl_login_underlined = "<u>Login</u>";
const learner_lbl_join = "Join";
const learner_lbl_don_t_joined_yet = "Don\'t Joined Yet !";
const learner_txt_terms_condition = "Terms & Condition";

const learner_lbl_featured = "Featured";
const learner_lbl_see_all = "See All";
const learner_lbl_categories = "Categories";
const learner_hint_search = "Search...";
const learner_lbl_filter = "Filter";
const learner_lbl_top_instructors = "Top Instructors";
const learner_lbl_recommended = "Recommended";

const learner_lbl_390_290_points = "390,290 Points";
const learner_lbl_general = "General";
const learner_lbl_favourite_courses = "Favourite Courses";
const learner_lbl_my_friends = "My Friends";
const learner_lbl_achievements = "Achievements";
const learner_lbl_settings = "Settings";
const learner_lbl_edit_login_details = "Edit Login Details";
const learner_lbl_update_interests = "Update Interests";
const learner_lbl_blocked_users = "Blocked users";

const learner_lbl_favourites = "Favourites";
const learner_lbl_locked_badge = "Locked Badge";
const learner_lbl_unlock_to_see_details = "Unlock to see details";
const learner_lbl_leader_board = "Leaderboard";
const learner_lbl_badges = "Badges";
const learner_lbl_My_Friends = "My Friends";
const learner_lbl_Accepted = "Accepted";
const learner_lbl_pending = "Pending";

const learner_lbl_Student = "Student";
const learner_lbl_Course = "COURSES";
const learner_lbl_Points = "POINTS";
const learner_lbl_Ranks = "RANKS";

const learner_lbl_My_Courses = "My Courses";
const learner_lbl_All = "All";
const learner_lbl_Ongoing = "Ongoing";
const learner_lbl_Completed = "Completed";
const learner_lbl_project_management = "Project Management";
const learner_lbl_30_80 = "\$30.80";
const learner_lbl_1_6k = "1.6K";
const learner_lbl_students = "Students";
const learner_lbl_rating = "Rating";
const learner_lbl_37 = "37";
const learner_lbl_lectures = "Lectures";
const learner_lbl_5_0 = "5.0";
const learner_lbl_swipe_up_to_show_course_contents = "Swipe up to show course contents";
const learner_lbl_hannah_tran = "Hannah Tran";

const learner_lbl_modren_medicine = "Modren Medicine";
const learner_lbl_Louisa_macGee = "Louisa macGee";
const learner_lbl_Lessons = "Lessons";
const learner_lbl_Reviews = "Reviews";
const learner_lbl_About = "About";
const learner_lbl_chat = "Chats";
const learner_lbl_Instrctors = "Instructors";
const learner_lbl_Friends = "Friends";
const learner_lbl_Bots = "Bots";
const learner_lbl_Start_a_new_chat = "START A NEW CHAT";
const learner_lbl_start = "Start";
const learner_lbl_Follow = "Follow";
const learner_lbl_Ratting = "RATTINGS";
const learner_lbl_Stud = "STUDENTS";
const learner_lbl_Introducation = "Introducation";
const learner_lbl_Article = "Article";
const learner_lbl_2K_Student = "2.8K STUNDENTS";
const learner_36_Lectures = "36 LECTURES";
