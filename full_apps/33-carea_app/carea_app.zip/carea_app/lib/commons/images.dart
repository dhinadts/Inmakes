const car = 'assets/car.png';
const loding = 'assets/loading.png';
const bugati = 'assets/bugati.jpeg';
const whiteCar = 'assets/white_car.jpg';
const whiteCar1 = 'assets/white_car1.jpg';
const whiteCar2 = 'assets/white_car2.jpg';
const google = 'assets/google.png';
const facebook = 'assets/facebook-logo.png';
const apple = 'assets/apple.png';
const fingerprint = 'assets/fingerprint.png';
const profile = 'assets/profile.png';
const forgotpass = 'assets/forgotpass.png';
const createpassimg = 'assets/createpassimg.png';

// list of car name
const honda = 'assets/honda.png';
const mersedis = 'assets/mersades.png';
const more = 'assets/more.png';
const tesla = "assets/tesla.png";
const toyata = 'assets/Toyota.png';
const volvo = 'assets/volvo.png';
const bmw = 'assets/bmw.png';
const buggatti = 'assets/buggatti.png';

const car0 = 'assets/car.png';
const car1 = 'assets/car1.png';
const car2 = 'assets/car2.png';
const car3 = 'assets/car3.png';
const car4 = 'assets/car4.png';
const car5 = 'assets/car5.png';
const car6 = 'assets/car6.png';
const car7 = 'assets/car7.png';
const car8 = 'assets/car8.png';
const car9 = 'assets/car9.png';
const car10 = 'assets/car10.png';
const car11 = 'assets/car11.png';
const car12 = 'assets/car12.png';
const car13 = 'assets/car13.png';

const bmwgif = 'assets/bmw.gif';
const car_gif = 'assets/car_gif.gif';
const wrongkeyword = 'assets/wrongkeyword.png';
