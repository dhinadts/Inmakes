package com.iconic.carea

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
