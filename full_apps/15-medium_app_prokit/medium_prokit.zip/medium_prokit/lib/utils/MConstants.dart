const MAppName = 'Blogger';
const detailsUrl = "https://medium.com/agile-freaks/android-dynamic-bottom-navigation-e6818942e27a";
const BaseUrl = 'https://assets.iqonic.design/old-themeforest-images/prokit';
