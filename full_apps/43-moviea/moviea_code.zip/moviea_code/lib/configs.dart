const APP_NAME = 'Moviea';
const DEFAULT_LANGUAGE = 'en';
const BaseUrl = '';
