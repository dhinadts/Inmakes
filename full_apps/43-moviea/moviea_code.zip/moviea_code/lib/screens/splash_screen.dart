import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:moviebook/utils/colors.dart';
import 'package:nb_utils/nb_utils.dart';

import '../configs.dart';
import '../utils/images.dart';
import 'walk_through/view/walk_through_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    afterBuildCreated(() {
      SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        systemNavigationBarColor: context.scaffoldBackgroundColor,
        systemNavigationBarDividerColor: Colors.transparent,
        statusBarColor: context.scaffoldBackgroundColor,
        statusBarIconBrightness: Brightness.dark,
      ));
    });

    Timer(const Duration(seconds: 3), () {
      const WalkThroughScreen().launch(context, isNewTask: true);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              child: Image.network(logoGif, height: 120, width: 120, fit: BoxFit.cover),
            ),
            Text(
              APP_NAME,
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.w600,
                color: primaryColor,
                fontFamily: GoogleFonts.lexendDeca().fontFamily,
              ),
            ).paddingSymmetric(horizontal: 16),
          ],
        ),
      ),
    );
  }
}
