//region THEME MODE TYPE
class ThemeConst {
  static const THEME_MODE_LIGHT = true;
  static const THEME_MODE_DARK = false;
}

const LABEL_TEXT_SIZE = 35;
