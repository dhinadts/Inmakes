package com.example.moviebook

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
