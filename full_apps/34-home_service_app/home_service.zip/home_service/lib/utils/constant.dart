const String appName = 'Home Service';

double mainTitleTextSize = 32;
