import 'package:event_prokit/utils/EAConstants.dart';

const event_ic_logo = "const event_ic_logo";
const event_ic_walk_through1 = "$BaseUrl/images/eventApp/pageview1.jpg";
const event_ic_walk_through2 = "$BaseUrl/images/eventApp/pageview2.jpg";
const event_ic_walk_through3 = "$BaseUrl/images/eventApp/pageview3.jpg";
const event_ic_festival = "$BaseUrl/images/eventApp/festival.jpg";
const event_ic_facebook = "$BaseUrl/images/eventApp/event_ic_facebook.png";
const event_ic_london = "$BaseUrl/images/eventApp/london.jpg";
const event_ic_newYork = "$BaseUrl/images/eventApp/newyork.jpg";
const event_ic_paris = "$BaseUrl/images/eventApp/paris.jpg";
const event_ic_tokyo = "$BaseUrl/images/eventApp/tokyo.jpg";
const event_ic_music = "$BaseUrl/images/eventApp/music.jpeg";
const event_ic_food = "$BaseUrl/images/eventApp/food.jpg";
const event_ic_cinema = "$BaseUrl/images/eventApp/cinema.jpg";
const event_ic_visa = "$BaseUrl/images/eventApp/visa.png";
const event_ic_master = "$BaseUrl/images/eventApp/paypal.png";
const event_ic_amex = "$BaseUrl/images/eventApp/amex.png";
const event_ic_map = "$BaseUrl/images/eventApp/map.jpg";
