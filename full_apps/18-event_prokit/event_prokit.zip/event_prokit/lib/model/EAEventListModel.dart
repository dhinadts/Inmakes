class EAEventList{
  String? image;
  String? name;
  String? date;

  EAEventList({this.image, this.name, this.date});
}