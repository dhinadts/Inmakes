import 'package:flutter/material.dart';
import 'package:musicpodcast_prokit/models/MusicModel.dart';
import 'package:musicpodcast_prokit/screen/MPProfileScreen.dart';
import 'package:musicpodcast_prokit/utils/MPImages.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:musicpodcast_prokit/screen/MPAlbumsScreen.dart';
import 'package:musicpodcast_prokit/screen/MPArtistsScreen.dart';
import 'package:musicpodcast_prokit/screen/MPEventsScreen.dart';
import 'package:musicpodcast_prokit/screen/MPNewsScreen.dart';
import 'package:musicpodcast_prokit/screen/MPPlayListScreen.dart';
import 'package:musicpodcast_prokit/screen/MPPodCastScreen.dart';
import 'package:musicpodcast_prokit/screen/MPSettingScreen.dart';
import 'package:musicpodcast_prokit/screen/MPSongsScreen.dart';

List<DrawerList> getDrawerList() {
  List<DrawerList> drawerList = [];
  drawerList.add(DrawerList(name: "Profile", widget: MPProfileScreen(isTab: true)));
  drawerList.add(DrawerList(name: "Songs", widget: MPSongsScreen()));
  drawerList.add(DrawerList(name: "Artists", widget: MPArtistsScreen(name: 'Artists')));
  drawerList.add(DrawerList(name: "Albums", widget: MPAlbumsScreen(isTab: false)));
  drawerList.add(DrawerList(name: "Podcasts", widget: MPPodCastScreen(name: 'Podcasts')));
  drawerList.add(DrawerList(name: "News", widget: MPNewsScreen(name: 'News')));
  drawerList.add(DrawerList(name: "Events", widget: MPEventsScreen(name: 'Events')));
  drawerList.add(DrawerList(name: "Playlist", widget: MPPlayListScreen()));
  drawerList.add(DrawerList(name: "Setting", widget: MPSettingScreen()));

  return drawerList;
}

List<NewsList> getNewsList() {
  List<NewsList> newsList = [];
  newsList.add(NewsList(
      img: mpImages_1,
      name: "Melodic Harmony",
      description:
          "Melodic harmony combines different melodies in a piece of music, creating a rich and layered sound. It’s the interplay between notes that enhances the overall musical experience."));
  newsList.add(NewsList(
      img: mpImages_3, name: "Rhythmic Pulse", description: "The rhythmic pulse is the steady beat that drives the tempo of a song. It’s the heartbeat of the music, giving it energy and momentum."));
  newsList.add(NewsList(
      img: mpImages_5,
      name: "Bass Groove",
      description: "The bass groove refers to the rhythm and feel provided by the bass line in a track. It’s essential for creating the foundation and vibe of many musical genres."));
  newsList.add(NewsList(
      img: mpImages_7,
      name: "Sound Waves",
      description: "Sound waves are the vibrations that travel through the air, allowing us to hear music and other sounds. They are the fundamental building blocks of audio."));

  return newsList;
}

List<MusicModel> getDisCoverList() {
  List<MusicModel> list = [];
  list.add(MusicModel(title: "Sound Of Water", img: mpImages_1, subtitle: "Denise Brewer"));
  list.add(MusicModel(title: "The For Carnation", img: mpImages_2, subtitle: "Dylan Meringur"));
  list.add(MusicModel(title: "Sound Of Water", img: mpImages_1, subtitle: "Denise Brewer"));
  list.add(MusicModel(title: "The For Carnation", img: mpImages_2, subtitle: "Dylan Meringur"));
  list.add(MusicModel(title: "Sound Of Water", img: mpImages_1, subtitle: "Denise Brewer"));

  return list;
}

List<MusicModel> getSongsList() {
  List<MusicModel> songsList = [];

  songsList.add(MusicModel(title: "Midnight Echoes", subtitle: "Luna Blue", number1: 3.5, like: false));
  songsList.add(MusicModel(title: "Whispers in the Wind", subtitle: "Aurora Sky", number1: 4.0, like: true));
  songsList.add(MusicModel(title: "Electric Dreams", subtitle: "Neon Vibes", number1: 1.5, like: false));
  songsList.add(MusicModel(title: "Chasing Shadows", subtitle: "Echo Fields", number1: 3.5, like: false));
  songsList.add(MusicModel(title: "Golden Horizon", subtitle: "Sienna Dawn", number1: 4.0, like: true));
  songsList.add(MusicModel(title: "Fading Stars", subtitle: "Nova Waves", number1: 2.5, like: false));
  songsList.add(MusicModel(title: "Crimson Heartbeat", subtitle: "Ruby Fire", number1: 3.5, like: true));
  songsList.add(MusicModel(title: "Ocean’s Lullaby", subtitle: "Marina Tide", number1: 1.0, like: false));
  songsList.add(MusicModel(title: "Velvet Moonlight", subtitle: "Indigo Night", number1: 2.0, like: true));
  songsList.add(MusicModel(title: "Whirlwind Embrace", subtitle: "Zephyr Storm", number1: 3.0, like: false));

  return songsList;
}

List<MusicModel> getArtistsList() {
  List<MusicModel> list = [];
  list.add(MusicModel(title: "Luna Blue", img: mpImages_7));
  list.add(MusicModel(title: "Aurora Sky", img: mpImages_9));
  list.add(MusicModel(title: "Neon Vibes", img: mpImages_11));
  list.add(MusicModel(title: "Echo Fields", img: mpImages_13));
  list.add(MusicModel(title: "Sienna Dawn", img: mpImages_15));
  list.add(MusicModel(title: "Nova Waves", img: mpImages_17));
  list.add(MusicModel(title: "Ruby Fire", img: mpImages_2));
  list.add(MusicModel(title: "Marina Tide", img: mpImages_4));
  list.add(MusicModel(title: "Indigo Night", img: mpImages_6));
  list.add(MusicModel(title: "Zephyr Storm", img: mpImages_8));

  return list;
}

List<MusicModel> getTrendList1() {
  List<MusicModel> trendList1 = [];
  trendList1.add(MusicModel(title: 'Radio Super', img: mpImages_10, subtitle: '98.3 Hz'));
  trendList1.add(MusicModel(title: 'Radio Jazz', img: mpImages_12, subtitle: '94.4 Hz'));
  trendList1.add(MusicModel(title: 'Radio Podcast', img: mpImages_14, subtitle: '91.6 Hz'));
  trendList1.add(MusicModel(title: 'Radio Metal', img: mpImages_16, subtitle: '93.8 Hz'));
  trendList1.add(MusicModel(title: 'Radio Artist', img: mpImages_3, subtitle: '101.01 Hz'));
  trendList1.add(MusicModel(title: 'Radio Hip Hop', img: mpImages_6, subtitle: '25.5 Hz'));
  trendList1.add(MusicModel(title: 'Radio Punk', img: mpImages_9, subtitle: '12.5 Hz'));
  trendList1.add(MusicModel(title: 'Radio Classic', img: mpImages_12, subtitle: '98.5 Hz'));
  trendList1.add(MusicModel(title: 'Radio Pop', img: mpImages_15, subtitle: '96.8 Hz'));
  trendList1.add(MusicModel(title: 'Radio Albums', img: mpImages_17, subtitle: '100.5 Hz'));

  return trendList1;
}

List<MusicModel> getPodCastDetailList() {
  List<MusicModel> podCastDetailList = [];
  podCastDetailList.add(MusicModel(title: "Episodes 1", subtitle: "2 July, 2008", number1: 42.25));
  podCastDetailList.add(MusicModel(title: "Episodes 2", subtitle: "11 Sep, 2012", number1: 41.24));
  podCastDetailList.add(MusicModel(title: "Episodes 3", subtitle: "25 June, 2018", number1: 35.25));
  podCastDetailList.add(MusicModel(title: "Episodes 4", subtitle: "30 Aug, 2015", number1: 30.55));
  podCastDetailList.add(MusicModel(title: "Episodes 5", subtitle: "06 Dec, 2016", number1: 22.51));
  podCastDetailList.add(MusicModel(title: "Episodes 6", subtitle: "10 Nov, 2012", number1: 41.22));

  return podCastDetailList;
}

List<MusicModel> getPodCastList() {
  List<MusicModel> podCastList = [];
  podCastList.add(MusicModel(title: "Echoes", img: mpImages_17, subtitle: "Luna"));
  podCastList.add(MusicModel(title: "Vibes", img: mpImages_16, subtitle: "Aurora"));
  podCastList.add(MusicModel(title: "Dreams", img: mpImages_15, subtitle: "Neon"));
  podCastList.add(MusicModel(title: "Shadows", img: mpImages_14, subtitle: "Echo"));
  podCastList.add(MusicModel(title: "Horizon", img: mpImages_13, subtitle: "Sienna"));
  podCastList.add(MusicModel(title: "Stars", img: mpImages_12, subtitle: "Nova"));
  podCastList.add(MusicModel(title: "Heartbeat", img: mpImages_11, subtitle: "Ruby"));
  podCastList.add(MusicModel(title: "Lullaby", img: mpImages_10, subtitle: "Marina"));
  podCastList.add(MusicModel(title: "Moonlight", img: mpImages_9, subtitle: "Indigo"));
  podCastList.add(MusicModel(title: "Embrace", img: mpImages_8, subtitle: "Zephyr"));

  return podCastList;
}

List<MusicModel> getDisCoverGridList() {
  List<MusicModel> list = [];
  list.add(MusicModel(img: mpImages_17, title: "Sound Of Water", number: 251, subtitle: "30 tracks"));
  list.add(MusicModel(img: mpImages_16, title: "The For Carnation", number: 100, subtitle: "20 tracks"));
  list.add(MusicModel(img: mpImages_15, title: "Road Trip", number: 251, subtitle: "25 tracks"));
  list.add(MusicModel(img: mpImages_14, title: "Sound Of Water", number: 150, subtitle: "30 tracks"));
  list.add(MusicModel(img: mpImages_13, title: "The For Carnation", number: 251, subtitle: "20 tracks"));
  list.add(MusicModel(img: mpImages_12, title: "Road Trip", number: 351, subtitle: "25 tracks"));
  list.add(MusicModel(img: mpImages_11, title: "Road Trip", number: 251, subtitle: "42 tracks"));
  list.add(MusicModel(img: mpImages_10, title: "Road Trip", number: 151, subtitle: "38 tracks"));
  list.add(MusicModel(img: mpImages_9, title: "Road Trip", number: 251, subtitle: "30 tracks"));
  list.add(MusicModel(img: mpImages_8, title: "Road Trip", number: 341, subtitle: "20 tracks"));

  return list;
}

List<MusicModel> getArtistsDetailAlbumList() {
  List<MusicModel> artistsDetailAlbumList = [];
  artistsDetailAlbumList.add(MusicModel(img: mpImages_11, title: "Luna", number: 2017));
  artistsDetailAlbumList.add(MusicModel(img: mpImages_15, title: "Aurora", number: 2008));
  artistsDetailAlbumList.add(MusicModel(img: mpImages_10, title: "Neon", number: 2010));
  artistsDetailAlbumList.add(MusicModel(img: mpImages_4, title: "Echo", number: 2014));
  artistsDetailAlbumList.add(MusicModel(img: mpImages_8, title: "Sienna", number: 2018));
  artistsDetailAlbumList.add(MusicModel(img: mpImages_14, title: "Nova", number: 2009));

  return artistsDetailAlbumList;
}

List<MusicModel> getProfileGridList() {
  List<MusicModel> list = [];
  list.add(MusicModel(img: mpImages_3, title: "Sound Of Water"));
  list.add(MusicModel(img: mpImages_5, title: "The For Carnation"));
  list.add(MusicModel(img: mpImages_7, title: "Road Trip"));
  list.add(MusicModel(img: mpImages_9, title: "Sound Of Water"));
  list.add(MusicModel(img: mpImages_11, title: "The For Carnation"));
  list.add(MusicModel(img: mpImages_13, title: "Road Trip"));
  list.add(MusicModel(img: mpImages_15, title: "Road Trip"));
  list.add(MusicModel(img: mpImages_17, title: "Road Trip"));
  return list;
}

List<MusicModel> getAlbumsList() {
  List<MusicModel> list = [];
  list.add(MusicModel(img: mpImages_10, title: "Sound Of Water", subtitle: "Denise Brewer"));
  list.add(MusicModel(img: mpImages_13, title: "The For Carnation", subtitle: "Dylan Meringur"));
  list.add(MusicModel(img: mpImages_7, title: "Road Trip", subtitle: "Denise Brewer"));
  list.add(MusicModel(img: mpImages_2, title: "Sound Of Water", subtitle: "Dylan Meringur"));
  list.add(MusicModel(img: mpImages_5, title: "The For Carnation", subtitle: "Richard Tea"));
  list.add(MusicModel(img: mpImages_1, title: "Road Trip", subtitle: "25 tracks"));
  list.add(MusicModel(img: mpImages_11, title: "Road Trip", subtitle: "The For Carnation"));
  list.add(MusicModel(img: mpImages_17, title: "Road Trip", subtitle: "Sound Of Water"));
  return list;
}

List<MusicModel> getAlbumGridList() {
  List<MusicModel> list = [];
  list.add(MusicModel(img: mpImages_2, title: "Road Trip", subtitle: "Since I Left You"));
  list.add(MusicModel(img: mpImages_4, title: "Road Trip", subtitle: "Sea Change"));
  list.add(MusicModel(img: mpImages_6, title: "Road Trip", subtitle: "Tune For The Road"));
  list.add(MusicModel(img: mpImages_8, title: "Road Trip", subtitle: "I Miss YOu"));
  list.add(MusicModel(img: mpImages_10, title: "Sound Of Water", subtitle: "Walk Of Time"));
  list.add(MusicModel(img: mpImages_12, title: "The For Carnation", subtitle: "Come With Me"));
  list.add(MusicModel(img: mpImages_14, title: "Road Trip", subtitle: "Sea Change"));
  list.add(MusicModel(img: mpImages_16, title: "Sound Of Water", subtitle: "Tune For The Road"));
  list.add(MusicModel(img: mpImages_7, title: "The For Carnation", subtitle: "Sound Of Water"));
  list.add(MusicModel(img: mpImages_9, title: "Road Trip", subtitle: "Since I Left You"));

  return list;
}

List<MusicModel> getAlbumDetailList() {
  List<MusicModel> list = [];
  list.add(MusicModel(title: "Tune For The Road", subtitle: "2:45"));
  list.add(MusicModel(title: "Giving My Bed", subtitle: "3:45"));
  list.add(MusicModel(title: "Golden Dreams", subtitle: "7:05"));
  list.add(MusicModel(title: "Sound Of Water", subtitle: "5:12"));
  list.add(MusicModel(title: "Tune For The Road", subtitle: "4:45"));
  list.add(MusicModel(title: "The For Carnation", subtitle: "8:45"));
  list.add(MusicModel(title: "Giving My Bed", subtitle: "4:45"));
  list.add(MusicModel(title: "Walk Of Time", subtitle: "3:50"));
  list.add(MusicModel(title: "Second Of You", subtitle: "2:45"));
  list.add(MusicModel(title: "Rock Radio", subtitle: "1:15"));
  list.add(MusicModel(title: "Golden Dreams", subtitle: "3:45"));
  list.add(MusicModel(title: "Tune For The Road", subtitle: "5:45"));
  return list;
}

List<MusicModel> getSongList() {
  List<MusicModel> list = [];

  list.add(MusicModel(title: "New Releases", color: Colors.pinkAccent));
  list.add(MusicModel(title: "Podcasts", color: Colors.lightGreen));
  list.add(MusicModel(title: "Artists", color: Colors.pink));
  list.add(MusicModel(title: "Hip Hop", color: Colors.blueAccent));
  list.add(MusicModel(title: "Pop", color: Colors.grey));
  list.add(MusicModel(title: "Jazz", color: Colors.green));
  list.add(MusicModel(title: "Metal", color: Colors.blue));
  list.add(MusicModel(title: "Fitness", color: Colors.pinkAccent));
  list.add(MusicModel(title: "RnB", color: Colors.lightGreen));
  list.add(MusicModel(title: "Hip Hop", color: Colors.pink));
  list.add(MusicModel(title: "Hop", color: Colors.blueAccent));
  list.add(MusicModel(title: "Pop", color: Colors.grey));
  list.add(MusicModel(title: "Jazz", color: Colors.green));
  list.add(MusicModel(title: "Metal", color: Colors.blue));

  return list;
}

List<MusicModel> getSongTypeList() {
  List<MusicModel> list = [];
  list.add(MusicModel(img: mpImages_3, title: "Road Trip", subtitle: "Since I Left You"));
  list.add(MusicModel(img: mpImages_7, title: "Road Trip", subtitle: "Sea Change"));
  list.add(MusicModel(img: mpImages_5, title: "Road Trip", subtitle: "Tune For The Road"));
  list.add(MusicModel(img: mpImages_9, title: "Road Trip", subtitle: "I Miss YOu"));
  list.add(MusicModel(img: mpImages_13, title: "Sound Of Water", subtitle: "Walk Of Time"));
  list.add(MusicModel(img: mpImages_11, title: "The For Carnation", subtitle: "Come With Me"));
  list.add(MusicModel(img: mpImages_17, title: "Road Trip", subtitle: "Sea Change"));
  list.add(MusicModel(img: mpImages_16, title: "Sound Of Water", subtitle: "Tune For The Road"));
  list.add(MusicModel(img: mpImages_15, title: "The For Carnation", subtitle: "Sound Of Water"));
  list.add(MusicModel(img: mpImages_12, title: "Road Trip", subtitle: "Since I Left You"));

  return list;
}

List<MusicModel> getProfileList() {
  List<MusicModel> list = [];
  list.add(MusicModel(title: "Profile", isShow: true));
  list.add(MusicModel(title: "Edit Profile", isShow: true, icon: (Icons.keyboard_arrow_right_outlined)));
  list.add(MusicModel(title: "Your Email", isShow: true, icon: (Icons.keyboard_arrow_right_outlined)));
  list.add(MusicModel(title: "Reset Password", isShow: true, icon: (Icons.keyboard_arrow_right_outlined)));
  list.add(MusicModel(title: "Notification"));
  list.add(MusicModel(title: "Location", isShow: true, icon: (Icons.keyboard_arrow_right_outlined)));
  list.add(MusicModel(title: "Support", isShow: true, icon: (Icons.keyboard_arrow_right_outlined)));
  list.add(MusicModel(title: "Terms and Conditions", isShow: true, icon: (Icons.keyboard_arrow_right_outlined)));
  list.add(MusicModel(title: "Location", isShow: true));

  return list;
}

List<MusicModel> getPlayDetailList() {
  List<MusicModel> playDetailList = [];
  playDetailList.add(MusicModel(title: "Echoes", img: mpImages_2, subtitle: "Luna", number: 1));
  playDetailList.add(MusicModel(title: "Vibes", img: mpImages_10, subtitle: "Aurora", number: 2));
  playDetailList.add(MusicModel(title: "Dreams", img: mpImages_8, subtitle: "Neon", number: 3));
  playDetailList.add(MusicModel(title: "Shadows", img: mpImages_6, subtitle: "Echo", number: 4));
  playDetailList.add(MusicModel(title: "Horizon", img: mpImages_1, subtitle: "Sienna", number: 5));
  playDetailList.add(MusicModel(title: "Stars", img: mpImages_16, subtitle: "Nova", number: 6));
  playDetailList.add(MusicModel(title: "Heartbeat", img: mpImages_12, subtitle: "Ruby", number: 7));
  playDetailList.add(MusicModel(title: "Lullaby", img: mpImages_14, subtitle: "Marina", number: 8));
  playDetailList.add(MusicModel(title: "Moonlight", img: mpImages_7, subtitle: "Indigo", number: 9));
  playDetailList.add(MusicModel(title: "Embrace", img: mpImages_9, subtitle: "Zephyr", number: 10));

  return playDetailList;
}

List<MusicModel> getSelectedSongTypeList() {
  List<MusicModel> selectedSongTypeList = [];
  selectedSongTypeList.add(MusicModel(title: "Echoes", img: mpImages_2));
  selectedSongTypeList.add(MusicModel(title: "Vibes", img: mpImages_4));
  selectedSongTypeList.add(MusicModel(title: "Midnight Echoes", img: mpImages_6));
  selectedSongTypeList.add(MusicModel(title: "Whispers in the Wind", img: mpImages_8));
  selectedSongTypeList.add(MusicModel(title: "Electric Dreams", img: mpImages_10));
  selectedSongTypeList.add(MusicModel(title: "Chasing Shadows", img: mpImages_12));
  selectedSongTypeList.add(MusicModel(title: "Golden Horizon", img: mpImages_14));
  selectedSongTypeList.add(MusicModel(title: "Fading Stars", img: mpImages_5));
  selectedSongTypeList.add(MusicModel(title: "Crimson Heartbeat", img: mpImages_14));
  selectedSongTypeList.add(MusicModel(title: "Ocean’s Lullaby", img: mpImages_16));

  return selectedSongTypeList;
}

List<MusicModel> getDateList() {
  List<MusicModel> list = [];
  list.add(MusicModel(title: "10/11"));
  list.add(MusicModel(title: "11/11"));
  list.add(MusicModel(title: "12/11"));
  list.add(MusicModel(title: "13/11"));
  list.add(MusicModel(title: "14/11"));
  list.add(MusicModel(title: "15/11"));
  list.add(MusicModel(title: "16/11"));
  list.add(MusicModel(title: "17/11"));
  list.add(MusicModel(title: "18/11"));
  list.add(MusicModel(title: "19/11"));
  list.add(MusicModel(title: "20/11"));
  list.add(MusicModel(title: "21/11"));
  list.add(MusicModel(title: "22/11"));
  list.add(MusicModel(title: "23/11"));
  list.add(MusicModel(title: "24/11"));
  list.add(MusicModel(title: "25/11"));
  return list;
}

List<MusicModel> getEventsList() {
  List<MusicModel> list = [];
  list.add(MusicModel(img: mpImages_10, title: "Sound Of Water"));
  list.add(MusicModel(img: mpImages_15, title: "The For Carnation"));
  list.add(MusicModel(img: mpImages_17, title: "Road Trip"));
  list.add(MusicModel(img: mpImages_5, title: "Sound Of Water"));
  list.add(MusicModel(img: mpImages_1, title: "The For Carnation"));
  list.add(MusicModel(img: mpImages_9, title: "Road Trip"));
  list.add(MusicModel(img: mpImages_6, title: "Road Trip"));
  list.add(MusicModel(img: mpImages_3, title: "Road Trip"));
  return list;
}

List<MusicModel> getPlayList() {
  List<MusicModel> list = [];
  list.add(MusicModel(img: mPImage_1, title: "Road Trip", subtitle: "Since I Left You"));
  list.add(MusicModel(img: mPImage_2, title: "Road Trip", subtitle: "Sea Change"));
  list.add(MusicModel(img: mPImage_3, title: "Road Trip", subtitle: "Tune For The Road"));
  list.add(MusicModel(img: mPImage_4, title: "Road Trip", subtitle: "I Miss YOu"));
  list.add(MusicModel(img: mPImage_5, title: "Sound Of Water", subtitle: "Walk Of Time"));
  list.add(MusicModel(img: mPImage_6, title: "The For Carnation", subtitle: "Come With Me"));
  list.add(MusicModel(img: mPImage_1, title: "Road Trip", subtitle: "Since I Left You"));
  list.add(MusicModel(img: mPImage_2, title: "Road Trip", subtitle: "Sea Change"));
  list.add(MusicModel(img: mPImage_3, title: "Road Trip", subtitle: "Tune For The Road"));
  list.add(MusicModel(img: mPImage_4, title: "Road Trip", subtitle: "I Miss YOu"));
  list.add(MusicModel(img: mPImage_5, title: "Sound Of Water", subtitle: "Walk Of Time"));
  list.add(MusicModel(img: mPImage_6, title: "The For Carnation", subtitle: "Come With Me"));

  return list;
}

List<LanguageDataModel> languageList() {
  return [
    LanguageDataModel(id: 1, name: 'English', languageCode: 'en', fullLanguageCode: 'en-US', flag: 'images/flag/ic_us.png'),
    LanguageDataModel(id: 2, name: 'Hindi', languageCode: 'hi', fullLanguageCode: 'hi-IN', flag: 'images/flag/ic_hi.png'),
    LanguageDataModel(id: 3, name: 'Arabic', languageCode: 'ar', fullLanguageCode: 'ar-AR', flag: 'images/flag/ic_ar.png'),
    LanguageDataModel(id: 4, name: 'French', languageCode: 'fr', fullLanguageCode: 'fr-FR', flag: 'images/flag/ic_fr.png'),
  ];
}
