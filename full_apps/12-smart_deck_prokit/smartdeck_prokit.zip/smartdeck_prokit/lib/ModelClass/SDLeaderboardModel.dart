class SDLeaderBoardModel {
  String? image;
  String? name;
  String? message;
  int? score;

  SDLeaderBoardModel({
    this.image,
    this.name,
    this.message,
    this.score,
  });
}
