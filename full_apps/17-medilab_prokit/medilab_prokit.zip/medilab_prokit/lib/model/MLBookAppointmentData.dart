import 'package:flutter/material.dart';

class MLBookAppointmentData {
  String? id;
  String? title;
  Widget? widget;
  double? progress;

  MLBookAppointmentData({this.id, this.title, this.widget, this.progress});
}
