class MLOrderTrackData {
  String? date;
  String? message;
  String? time;
  String? stage;
  bool? value;

  MLOrderTrackData({this.date, this.time, this.stage, this.message, this.value});
}
