class MLDoctorData {
  String? title;
  String? subtitle;
  String? image;
  String? rating;
  String? fees;

  MLDoctorData({this.title, this.subtitle, this.image, this.rating, this.fees});
}
