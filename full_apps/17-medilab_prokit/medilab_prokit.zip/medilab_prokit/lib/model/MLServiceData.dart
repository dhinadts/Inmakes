import 'package:flutter/material.dart';

class MLServicesData {
  String? title;
  IconData? icon;
  String? image;
  Widget? widget;

  MLServicesData({this.title, this.icon, this.image, this.widget});
}
