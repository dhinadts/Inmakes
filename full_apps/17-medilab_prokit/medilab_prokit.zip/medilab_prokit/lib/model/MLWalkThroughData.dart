class MLWalkThroughData {
  String? imagePath;
  String? title;
  String? subtitle;

  MLWalkThroughData({this.imagePath, this.title, this.subtitle});
}
