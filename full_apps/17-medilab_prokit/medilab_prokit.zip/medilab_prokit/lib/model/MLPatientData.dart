class MLPatientData {
  String? name;
  String? dob;
  String? relation;

  MLPatientData({this.name, this.dob, this.relation});
}
