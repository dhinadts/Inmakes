class MLInboxData {
  int? id;
  String? message;

  MLInboxData({this.id, this.message});
}
